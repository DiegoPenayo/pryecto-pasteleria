import React from 'react'

const inicio = () => {
  return (
    <div>
        <h1>Inicio</h1>
    </div>
  )
}

export default inicio