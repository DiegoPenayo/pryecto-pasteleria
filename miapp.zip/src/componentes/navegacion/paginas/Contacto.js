import React from 'react'

const contacto = () => {
  return (
    <div>
        <h1>Contacto</h1>
    </div>
  )
}

export default contacto