import React from 'react'

const items = () => {
  return (
    <div><h1>Productos</h1></div>
  )
}

export default items